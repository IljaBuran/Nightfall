# AI-generated: GPT-6 assistant; user requested transparent-background versions of the approved Nightfall logos.

Nightfall transparent logo pack v1

Background removal performed with the built-in imagegen tool. RGBA transparency preserved in PNG size exports and the ICO. Ivory artwork, transparent surrounding canvas and negative spaces. Original black-background pack is unchanged.

Full logo: 256, 512, 1024 pixels square, plus master.
Symbol only: 16, 24, 32, 48, 64, 128, 256, 512, 1024 pixels square, plus master.
Windows icon: 16, 24, 32, 48, 64, 128, 256 pixel frames.

Artwork is pale ivory, best used on dark or colored backgrounds. These are raster assets, not vector files. No editor code or project configuration changed.

Imagegen prompt — full logo

Use case: background-extraction. Edit target: attached approved Nightfall logo.
Remove the black background ONLY and deliver a genuinely transparent RGBA PNG. Retain both the ivory N symbol AND the exact NIGHTFALL wordmark.
Preserve precisely the source image's canvas framing, logo placement, scale, proportions, outlines, rounded corners, diagonal gap, color and texture. Do not redraw, reinterpret, redesign, move, crop, recolor or add any logo element. Preserve all original ivory logo pixels and clean antialiased edges. Every black background area must become fully transparent, including the diagonal negative space inside the emblem and any enclosed spaces in the lettering. No black fringe, no added outline, no shadow, no white matte, and no checkerboard painted into the image. Preserve the original pale ivory foreground at full opacity in solid areas. Output only the original logo on true transparency, with no new text.

Imagegen prompt — symbol

Use case: background-extraction. Edit target: attached approved Nightfall logo.
Remove the black background ONLY and deliver a genuinely transparent RGBA PNG. Retain the ivory N symbol alone.
Preserve precisely the source image's canvas framing, logo placement, scale, proportions, outlines, rounded corners, diagonal gap, color and texture. Do not redraw, reinterpret, redesign, move, crop, recolor or add any logo element. Preserve all original ivory logo pixels and clean antialiased edges. Every black background area must become fully transparent, including the diagonal negative space inside the emblem and any enclosed spaces in the lettering. No black fringe, no added outline, no shadow, no white matte, and no checkerboard painted into the image. Preserve the original pale ivory foreground at full opacity in solid areas. Output only the original logo on true transparency, with no new text.
